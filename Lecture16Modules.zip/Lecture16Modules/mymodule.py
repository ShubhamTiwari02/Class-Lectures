def print_message(name):
    return "Hello, " + name + "! Welcome to my module."

def sum_numbers(a, b):
    return a + b

def multiply_numbers(a, b):
    return a * b

def divide_numbers(a, b):
    if b != 0:
        return a / b
    else:
        return "Error: Division by zero is not allowed."
    
def subtract_numbers(a, b):
    return a - b    

def power_numbers(a, b):
    return a ** b   

def modulus_numbers(a, b):
    return a % b

def floor_divide_numbers(a, b):
    return a // b