#from importlib import reload
#import mymodule 
import mymodule as mm #import with alias
#from mymodule import * 
#from mymodule import sum_numbers, multiply_numbers
#reload(mymodule)
'''
print(mymodule.print_message("Alice"))
#print(sum_numbers(5, 10))
print(mymodule.sum_numbers(5, 10))
#print(multiply_numbers(5, 10))
print(mymodule.multiply_numbers(5, 10))
print(mymodule.divide_numbers(5, 0))
print(mymodule.divide_numbers(10, 2))
print(mymodule.subtract_numbers(5, 10))
print(mymodule.power_numbers(5, 2))
print(mymodule.modulus_numbers(10, 3))
print(mymodule.floor_divide_numbers(100, 3))'''

print(mm.print_message("Alice"))
print(mm.sum_numbers(5, 10))    
print(mm.multiply_numbers(5, 10))
print(mm.divide_numbers(5, 0))
print(mm.divide_numbers(10, 2))
print(mm.subtract_numbers(5, 10))
print(mm.power_numbers(5, 2))
print(mm.modulus_numbers(10, 3))
print(mm.floor_divide_numbers(100, 3))

#print(dir(mm))

#Loading modules in Python
#The current directory
#The PYTHONPATH environment variable
#The standard library directories
#The site-packages directory